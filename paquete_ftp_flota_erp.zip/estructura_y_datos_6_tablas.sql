CREATE DATABASE IF NOT EXISTS dbequipos DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE dbequipos;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS repuestos_utilizados;
DROP TABLE IF EXISTS ordenes_trabajo;
DROP TABLE IF EXISTS despiece_equipos;
DROP TABLE IF EXISTS repuestos_catalogo;
DROP TABLE IF EXISTS sistemas_maquinaria;
DROP TABLE IF EXISTS equipos;

CREATE TABLE equipos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_interno VARCHAR(50) NOT NULL UNIQUE,
    marca VARCHAR(100) NOT NULL,
    modelo VARCHAR(100) NOT NULL,
    numero_serie VARCHAR(100),
    horas_motor DECIMAL(10,2) DEFAULT 0.00,
    estado ENUM('OPERATIVO', 'MANTENIMIENTO', 'FUERA_DE_SERVICIO') DEFAULT 'OPERATIVO',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE sistemas_maquinaria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE repuestos_catalogo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero_parte_oem VARCHAR(100) NOT NULL UNIQUE,
    descripcion VARCHAR(255) NOT NULL,
    stock_actual INT DEFAULT 0,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE despiece_equipos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipo_id INT NOT NULL,
    repuesto_id INT NOT NULL,
    sistema_id INT NOT NULL,
    cantidad_por_equipo INT DEFAULT 1,
    FOREIGN KEY (equipo_id) REFERENCES equipos(id) ON DELETE CASCADE,
    FOREIGN KEY (repuesto_id) REFERENCES repuestos_catalogo(id) ON DELETE RESTRICT,
    FOREIGN KEY (sistema_id) REFERENCES sistemas_maquinaria(id) ON DELETE RESTRICT,
    UNIQUE KEY unica_pieza_sistema (equipo_id, repuesto_id, sistema_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE ordenes_trabajo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipo_id INT NOT NULL,
    fecha_ingreso DATETIME NOT NULL,
    fecha_cierre DATETIME NULL,
    mecanico_asignado VARCHAR(150),
    tipo ENUM('PREVENTIVO', 'CORRECTIVO', 'PREDICTIVO') NOT NULL,
    horas_motor_actuales DECIMAL(10,2),
    estado ENUM('ABIERTA', 'EN_PROGRESO', 'CERRADA', 'CANCELADA') DEFAULT 'ABIERTA',
    observaciones TEXT,
    FOREIGN KEY (equipo_id) REFERENCES equipos(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE repuestos_utilizados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    orden_trabajo_id INT NOT NULL,
    repuesto_id INT NOT NULL,
    cantidad_usada INT NOT NULL,
    fecha_uso TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (orden_trabajo_id) REFERENCES ordenes_trabajo(id) ON DELETE CASCADE,
    FOREIGN KEY (repuesto_id) REFERENCES repuestos_catalogo(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- CARGA DE DATOS PARA EL NUEVO ESQUEMA RELACIONAL (6 TABLAS GEMINI)
-- Compatible 100% con: equipos, sistemas_maquinaria, repuestos_catalogo,
-- despiece_equipos, ordenes_trabajo y repuestos_utilizados.
-- ============================================================================
SET FOREIGN_KEY_CHECKS = 0;

-- 1. Carga de los 183 Equipos Reales en `equipos`
INSERT INTO `equipos` (`id`, `codigo_interno`, `marca`, `modelo`, `numero_serie`, `horas_motor`, `estado`) VALUES
(1, 'AC001', 'SALTO', 'ch 8,15/1988', '5245', 47120.0, 'OPERATIVO'),
(2, 'AC001-B', 'SALTO', 'ch 8,15/1988', '5245', 50240.0, 'OPERATIVO'),
(3, 'AC002', 'SALTO', 'CH 8,5', '5986', 53360.0, 'OPERATIVO'),
(4, 'AC003', 'FRUEHAUF', 'PB-F2HD', 'BAQ2135', 56480.0, 'OPERATIVO'),
(5, 'AC004', 'FRUEHAUF', 'NR NF3', '8C9N0863FV1002115', 59600.0, 'OPERATIVO'),
(6, 'AC005', 'SALTO', 'CH AC', '9488', 62720.0, 'OPERATIVO'),
(7, 'AC006', 'ROMAPAR', '', 'DOM-TAF 470', 65840.0, 'OPERATIVO'),
(8, 'AC007', 'SALTO', '', 'DOM-SZU 644', 68960.0, 'OPERATIVO'),
(9, 'AC008', 'BIANCHI', 'SRVT30-0387', '8A9SRVT305A022013', 72080.0, 'OPERATIVO'),
(10, 'AM001', 'BOSCH', 'GUUS 22-180', 'S/N-10', 110.0, 'OPERATIVO'),
(11, 'AM002', 'BOSCH', 'GUUS7', 'S/N-11', 121.0, 'OPERATIVO'),
(12, 'AP003', 'BITELLI', 'DRAGO', 'S/N-12', 3494.0, 'OPERATIVO'),
(13, 'ASJ004', 'WACKER', '', 'S/N-13', 143.0, 'OPERATIVO'),
(14, 'ASJ005', 'NORTON', '', 'S/N-14', 154.0, 'OPERATIVO'),
(15, 'ASJ006', 'NORTON', '', 'S/N-15', 165.0, 'OPERATIVO'),
(16, 'BA003', 'PLUSCARGA', 'S-BA/25-2004', '8A9S161BA10PSR729', 93920.0, 'OPERATIVO'),
(17, 'BOM003', 'Motorarg', 'DCO 1100M', 'S/N-17', 187.0, 'OPERATIVO'),
(18, 'BOM004', 'Motorarg', 'DCO 1100M', 'S/N-18', 198.0, 'OPERATIVO'),
(19, 'BOM005', 'Motorarg', 'DCO 1100M', 'S/N-19', 209.0, 'OPERATIVO'),
(20, 'CA013', 'SCANIA', 'R113 H', 'W2219243', 106400.0, 'OPERATIVO'),
(21, 'CA016', 'FORD', '749- CARGO 1832E', '9BFYCAWYXABB61466', 109520.0, 'OPERATIVO'),
(22, 'CA017', 'FORD', '743 CARGO 1317E', '9BFXCE2U5BBB79204', 112640.0, 'OPERATIVO'),
(23, 'CA018', 'FORD', 'CARGO 1722', '9BFYTNFT64BB38055', 115760.0, 'OPERATIVO'),
(24, 'CA019', 'FORD', 'F4000', '9BFLF47P5GB006774', 118880.0, 'OPERATIVO'),
(25, 'CA020', 'IVECO', '428- DAILY 55C17 PASO 3750', '93ZC53C01H8469656', 122000.0, 'OPERATIVO'),
(26, 'CA021', 'FORD', 'F4000', 'DOM-AC 224 WS', 125120.0, 'OPERATIVO'),
(27, 'CAR001', 'Industrial', '', 'S/N-27', 17.0, 'OPERATIVO'),
(28, 'CAR002', 'Industrial', '', 'S/N-28', 28.0, 'OPERATIVO'),
(29, 'CAR003', 'Industrial', '', 'S/N-29', 39.0, 'OPERATIVO'),
(30, 'CAR004', 'Industrial', '', 'S/N-30', 50.0, 'OPERATIVO'),
(31, 'CAR005', 'Industrial', '', 'S/N-31', 61.0, 'OPERATIVO'),
(32, 'CON001', 'Industrial', '', 'S/N-32', 72.0, 'OPERATIVO'),
(33, 'CON002', 'Dryzort', '', 'S/N-33', 83.0, 'OPERATIVO'),
(34, 'CON003', 'Comet', '', 'S/N-34', 94.0, 'OPERATIVO'),
(35, 'CON004', 'Industrial', 'INBU-39015-5', 'S/N-35', 105.0, 'OPERATIVO'),
(36, 'CON005', 'Industrial', '', 'S/N-36', 116.0, 'OPERATIVO'),
(37, 'CON006', 'BRANSEN', 'TIPO PAÃƒâ€˜OL', 'S/N-37', 127.0, 'OPERATIVO'),
(38, 'CON007', 'BRANSEN', 'TIPO OFICINA', 'S/N-38', 138.0, 'OPERATIVO'),
(39, 'CP002', 'CETEC', 'OTR 275A Serie', 'S/N-39', 7193.0, 'OPERATIVO'),
(40, 'CP003', 'INGERSOLL RAND', 'P250WJD', 'PE4045D580932', 7330.0, 'OPERATIVO'),
(41, 'CP004', 'ATLAS COPCO', 'XAS 185 JD HARD HAT', 'DOM-BP2321', 7467.0, 'OPERATIVO'),
(42, 'CP005', 'SULLAIR', '185Q-JD', 'J04045d674108', 7604.0, 'OPERATIVO'),
(43, 'CR001', 'Conrrado Iglesias', '', 'S/N-43', 178160.0, 'OPERATIVO'),
(44, 'CR002', 'Tecnagro', '', 'S/N-44', 181280.0, 'OPERATIVO'),
(45, 'CR003', 'Industrial', '', 'S/N-45', 184400.0, 'OPERATIVO'),
(46, 'CR004', 'Industrial', '', 'S/N-46', 187520.0, 'OPERATIVO'),
(47, 'CR006', 'Industrial', '', 'S/N-47', 190640.0, 'OPERATIVO'),
(48, 'CT001', 'PATRONELLI', 'SEM. CARR.3E', '000732', 193760.0, 'OPERATIVO'),
(49, 'CT002', 'S/M', '', 'S/N-49', 196880.0, 'OPERATIVO'),
(50, 'CT003', 'AP', '', 'S/N-50', 200000.0, 'OPERATIVO'),
(51, 'CT005', 'PATRONELLI', 'SEMCG3E', '8B9SGT3CMLA030044', 203120.0, 'OPERATIVO'),
(52, 'DE001', 'HERCULES', '', 'S/N-52', 12.0, 'OPERATIVO'),
(53, 'DE003', 'LUSQTOFF', 'LD-52', 'S/N-53', 23.0, 'OPERATIVO'),
(54, 'DTG001', 'BW Technologies', 'Gas Alert Micro 5', 'S/N-54', 34.0, 'OPERATIVO'),
(55, 'ETE002', 'INDHOR', '', 'S/N-55', 45.0, 'OPERATIVO'),
(56, 'ETO001', 'PENTAX', '', 'S/N-56', 56.0, 'OPERATIVO'),
(57, 'ETO002', 'PENTAX', '', 'S/N-57', 67.0, 'OPERATIVO'),
(58, 'ETO003', 'SOUTH', 'N7', 'S/N-58', 78.0, 'OPERATIVO'),
(59, 'FUS002', 'FRACCHIA', '', 'S/N-59', 3733.0, 'OPERATIVO'),
(60, 'GRE001', 'BOUNOUS', 'Yanmar 22/20', 'S/N-60', 3870.0, 'OPERATIVO'),
(61, 'GRE002', 'TOP MAN', '', 'S/N-61', 4007.0, 'OPERATIVO'),
(62, 'GRE003', 'BOUNOUS', 'ODB 04/9', 'S/N-62', 4144.0, 'OPERATIVO'),
(63, 'GRE004', 'SENSEI', '', 'S/N-63', 4281.0, 'OPERATIVO'),
(64, 'GRE005', 'GAMA', 'HZTPOS-12', 'S/N-64', 4418.0, 'OPERATIVO'),
(65, 'GRE006', 'KOREA', 'HP4I5', 'S/N-65', 4555.0, 'OPERATIVO'),
(66, 'GRE007', 'KOREA', 'HP 4I6,5Kw.', 'S/N-66', 4692.0, 'OPERATIVO'),
(67, 'GRE008', 'GAMA', '', 'DOM-HP 2IP05 220-12', 4829.0, 'OPERATIVO'),
(68, 'GRE010', 'LUSQTOFF', '10 kva', 'S/N-68', 4966.0, 'OPERATIVO'),
(69, 'GRE011', 'KIPOR', 'KDE19STA3', 'S/N-69', 5103.0, 'OPERATIVO'),
(70, 'GRE011-B', 'LUSQTOFF', '10 kva', 'S/N-70', 5240.0, 'OPERATIVO'),
(71, 'GRE012', 'KIPOR', 'Kde 19KVA', 'S/N-71', 5377.0, 'OPERATIVO'),
(72, 'GRE013', 'LUSQTOFF', '10GF2-4', 'S/N-72', 5514.0, 'OPERATIVO'),
(73, 'GRE014', 'LUSQTOFF', 'LG2500EX', 'S/N-73', 5651.0, 'OPERATIVO'),
(74, 'HOR001', 'Trompito', '', 'S/N-74', 254.0, 'OPERATIVO'),
(75, 'MA005', 'CETEC', 'M368277', 'S/N-75', 265.0, 'OPERATIVO'),
(76, 'MA006', 'CETEC', 'M368277', 'S/N-76', 276.0, 'OPERATIVO'),
(77, 'MA007', 'CETEC', 'M368277', 'S/N-77', 7.0, 'OPERATIVO'),
(78, 'MA008', 'SULLAIR', '', 'S/N-78', 18.0, 'OPERATIVO'),
(79, 'MAH002', 'Volvo', '', 'S/N-79', 29.0, 'OPERATIVO'),
(80, 'MAH001', 'JCB', '', 'S/N-80', 40.0, 'OPERATIVO'),
(81, 'MAH002-B', 'Volvo', '', 'S/N-81', 51.0, 'OPERATIVO'),
(82, 'MAT001', 'BOSCH', 'GSH 11 E', 'S/N-82', 62.0, 'OPERATIVO'),
(83, 'MG003', 'SENSEI', '', 'S/N-83', 73.0, 'OPERATIVO'),
(84, 'MN002', 'KOMATSU', '', 'DOM-GD 523', 7158.0, 'FUERA_DE_SERVICIO'),
(85, 'MN003', 'KOMATSU', '30701428', '1021', 7295.0, 'FUERA_DE_SERVICIO'),
(86, 'MN004', 'JOHN DEERE', '670G', 'DOM-BXT 93', 7432.0, 'OPERATIVO'),
(87, 'MSO001', 'MILLER', '', 'S/N-87', 117.0, 'OPERATIVO'),
(88, 'NV001', 'TOPCON', '', 'S/N-88', 128.0, 'OPERATIVO'),
(89, 'NV002', 'TOPCON', '', 'S/N-89', 139.0, 'OPERATIVO'),
(90, 'NV004', 'PENTAX', '', 'S/N-90', 150.0, 'OPERATIVO'),
(91, 'NV005', 'LEICA', 'NA324', 'S/N-91', 161.0, 'OPERATIVO'),
(92, 'PC003', 'KOMATSU', 'WA250', 'S/N-92', 2054.0, 'OPERATIVO'),
(93, 'PC005', 'JCB', '436 ZX', '1305420', 2191.0, 'OPERATIVO'),
(94, 'PC007', 'TIAN GONG', '028-ZL50H', '1010028', 2328.0, 'OPERATIVO'),
(95, 'PC008', 'CATERPILLAR', '787-226B-3', 'CAT0226BLDXZ01114', 2465.0, 'OPERATIVO'),
(96, 'PC009', 'CATERPILLAR', '787-226B-3', 'CAT0226BCDXZ01179', 2602.0, 'OPERATIVO'),
(97, 'PC010', 'VOLVO', 'MC70', 'HAR070WSPH2499507', 2739.0, 'OPERATIVO'),
(98, 'PC011', 'VOLVO', 'MC70', 'DOM-DJD 40', 2876.0, 'OPERATIVO'),
(99, 'PC012', 'VOLVO', 'MC70C', 'RAJ070WSTH2575609', 3013.0, 'OPERATIVO'),
(100, 'PC013', 'CATERPILLAR', '236D', '8FS05995', 3150.0, 'OPERATIVO'),
(101, 'PE001', 'WAGON DRILL', '', 'S/N-101', 3287.0, 'OPERATIVO'),
(102, 'PL001', 'BARBER GREENE', '', 'S/N-102', 3424.0, 'MANTENIMIENTO'),
(103, 'PMC001', 'Industrial', '2184', 'S/N-103', 3561.0, 'OPERATIVO'),
(104, 'PMC002', 'Industrial', '2212', 'S/N-104', 3698.0, 'OPERATIVO'),
(105, 'PRE005', 'JOHN DEERE', 'SJ310', 'DOM-BYA 17', 3835.0, 'OPERATIVO'),
(106, 'PRE008', 'HYUNDAI', '940H', 'HHKHU601VG0000660', 3972.0, 'OPERATIVO'),
(107, 'PRE009', 'HYUNDAI', '940H', 'HBRH940CEG0000008', 4109.0, 'OPERATIVO'),
(108, 'PRE010', 'KOMATSU', 'WB97R', 'KMTWB0244AHUF90314', 4246.0, 'OPERATIVO'),
(109, 'PRE011', 'KOMATSU', 'WB97R', 'KMTWB024CHUF90410', 4383.0, 'OPERATIVO'),
(110, 'PRE012', 'KOMATSU', 'WB97R', 'DOM-DJD 63', 4520.0, 'OPERATIVO'),
(111, 'PRE013', 'KOMATSU', 'WB97R', 'DOM-DQH93', 4657.0, 'OPERATIVO'),
(112, 'RE006', 'JCB', 'JS200 LC', 'JCBJS20DK81611073', 4794.0, 'OPERATIVO'),
(113, 'RE009', 'CATERPILLAR', '635320D L', 'CAT0320DCA8F01610', 4931.0, 'OPERATIVO'),
(114, 'RE010', 'KOMATSU', 'PC-450 LC-7', 'S/N-114', 5068.0, 'OPERATIVO'),
(115, 'RE011', 'HYUNDAI', 'ROBEX 500 LC-6', 'HHIHNB06TB00018', 5205.0, 'OPERATIVO'),
(116, 'RE012', 'KOMATSU', 'PC-200 LC-8', 'KMTPC180CEBB33110', 5342.0, 'OPERATIVO'),
(117, 'RE013', 'HYUNDAI', 'ROBEX 60', 'HKHM909TF0005310', 5479.0, 'OPERATIVO'),
(118, 'RE014', 'JOHN DEERE', '35D', '1FF035DXECG268982', 5616.0, 'OPERATIVO'),
(119, 'RE015', 'VOLVO', 'EC55BPRO', 'VCEEC55BT00039139', 5753.0, 'OPERATIVO'),
(120, 'RE016', 'KOMATSU', 'PC-200 LC-8', 'KMTPC244LHBB50312', 5890.0, 'OPERATIVO'),
(121, 'RE017', 'KOMATSU', 'PC-200', 'KMTPC244HHBB50327', 6027.0, 'OPERATIVO'),
(122, 'RE018', 'HYUNDAI', 'Robex 220 LC-9SB?', '36573562', 6164.0, 'OPERATIVO'),
(123, 'RE019', 'HYUNDAI', 'ROBEX 35Z-9', '105109', 6301.0, 'OPERATIVO'),
(124, 'RE020', 'CATERPILLAR', '336DLME', 'DOM-BZQ77', 6438.0, 'OPERATIVO'),
(125, 'RN001', 'DYNAPAC', '', 'S/N-125', 6575.0, 'OPERATIVO'),
(126, 'RN003', 'HATRA', '', 'DOM-GW 27', 6712.0, 'OPERATIVO'),
(127, 'RPC001', 'DYNAPAC', 'CA-25', '709B777', 6849.0, 'OPERATIVO'),
(128, 'SOL001', 'LUSQTOFF', 'Iron 250 5TA', 'S/N-128', 8.0, 'OPERATIVO'),
(129, 'TA001', 'Industrial', '', 'S/N-129', 126480.0, 'OPERATIVO'),
(130, 'TA002', 'Industrial', '', 'S/N-130', 129600.0, 'OPERATIVO'),
(131, 'TA003', 'Industrial', '', 'S/N-131', 132720.0, 'OPERATIVO'),
(132, 'TA004', 'Industrial', '', 'S/N-132', 135840.0, 'OPERATIVO'),
(133, 'TA005', 'Industrial', '', 'S/N-133', 138960.0, 'OPERATIVO'),
(134, 'TA006', 'Industrial', '', 'S/N-134', 142080.0, 'OPERATIVO'),
(135, 'TA007', 'Grosspal', 'AT 1500', 'S/N-135', 145200.0, 'OPERATIVO'),
(136, 'TA008', 'Industrial', '', 'S/N-136', 148320.0, 'OPERATIVO'),
(137, 'TAL001', 'BOSCH', '', 'S/N-137', 107.0, 'OPERATIVO'),
(138, 'TAL002', 'BOSCH', '', 'S/N-138', 118.0, 'OPERATIVO'),
(139, 'TAL003', 'BOSCH', '', 'S/N-139', 129.0, 'OPERATIVO'),
(140, 'TAL004', 'BOSCH', '', 'S/N-140', 140.0, 'OPERATIVO'),
(141, 'TAS001', 'Industrial', '', 'S/N-141', 151.0, 'OPERATIVO'),
(142, 'TAS002', 'Industrial', '', 'S/N-142', 162.0, 'OPERATIVO'),
(143, 'TE002', 'MARINI', '', 'S/N-143', 2841.0, 'OPERATIVO'),
(144, 'TE002-B', 'P230', 'DEUTHZ', 'S/N-144', 2978.0, 'OPERATIVO'),
(145, 'TU001', 'HELIX', 'PHHR 530', 'DOM-BP2337', 3115.0, 'OPERATIVO'),
(146, 'TU002', 'HAMMERHEAD', '2"', 'S/N-146', 3252.0, 'OPERATIVO'),
(147, 'TU003', 'HAMMERHEAD', '2,5PP', 'S/N-147', 3389.0, 'OPERATIVO'),
(148, 'TU004', 'HELIX', 'PHETIPO3000', 'S/N-148', 3526.0, 'OPERATIVO'),
(149, 'TU005', 'HELIX', 'PHETIPO3000', 'S/N-149', 3663.0, 'OPERATIVO'),
(150, 'UM016', 'FORD', 'Curier', 'DOM-JFO 662', 192000.0, 'OPERATIVO'),
(151, 'UM018', 'VOLKWAGEN', 'Gol', '9BWAB05U2BT123042', 195120.0, 'OPERATIVO'),
(152, 'UM020', 'TOYOTA', 'Corolla XLI 1,8', '9BRBU42EXC4700353', 198240.0, 'OPERATIVO'),
(153, 'UM021', 'REANULT', 'KANGOO', 'sa1kcf705cl837032', 201360.0, 'OPERATIVO'),
(154, 'UM022', 'ASIA', 'Topic', 'KN4FAK2OTC021468', 44480.0, 'MANTENIMIENTO'),
(155, 'UM023', 'ASIA', 'Topic', 'KN4FAK2AORC021467', 47600.0, 'MANTENIMIENTO'),
(156, 'UM024', 'FORD', 'Ranger 4x2 Safety 2,2L D', '8AFAR22J3DJ125692', 50720.0, 'OPERATIVO'),
(157, 'UM025', 'FORD', 'Ranger2 DC 4x2 Safety 2,2L D', '8AFAR22JXEJ135699', 53840.0, 'OPERATIVO'),
(158, 'UM026', 'REANULT', 'DUSTER', '9FBHSR1N5EM018231', 56960.0, 'OPERATIVO'),
(159, 'UM027', 'REANULT', 'KANGOO', '8A1FC1315EL987132', 60080.0, 'OPERATIVO'),
(160, 'UM028', 'PEUGEOT', 'PARTNER PATAGONICA HDI 1,6 VTC PLUS', '8ADGJ9HJCFG524266', 63200.0, 'OPERATIVO'),
(161, 'UM029', 'PEUGEOT', '408 SPORT 163 CV', '8AD4D5FMJFG025225', 66320.0, 'OPERATIVO'),
(162, 'UM030', 'TOYOTA', 'HILUX 3,0 TDI DC DR 4X2', '8AJEZ32GXF1018336', 69440.0, 'OPERATIVO'),
(163, 'UM031', 'TOYOTA', 'HILUX 4X2 C/D PCK Electrico 2,5 tdi - h3', '8AJER32G9F4060298', 72560.0, 'OPERATIVO'),
(164, 'UM032', 'FORD', 'Ranger 2,5 DC 4x2L/16 XL Safety 2017', '8AFAR22P5JJ055855', 75680.0, 'OPERATIVO'),
(165, 'UM033', 'FORD', 'Ranger 2,5 DC 4x2L/16 XL Safety 2017', '8AFAR22P5JJ052907', 78800.0, 'OPERATIVO'),
(166, 'UM034', 'FORD', 'MONDEO SEL 2,0 ECOBOOST 4 PTAS', '3FA6POH98JR126235', 81920.0, 'OPERATIVO'),
(167, 'UM035', 'Toyota', 'Hilux', '8ajdr22g284007936', 85040.0, 'OPERATIVO'),
(168, 'UM036', 'Chevrolet', 'prisma', 'DOM-AC751UE', 88160.0, 'OPERATIVO'),
(169, 'UM037', 'VOLKSWAGEN', 'SAVEIRO 1,6', '9BWLB45U4HP069938', 91280.0, 'OPERATIVO'),
(170, 'UM038', 'FORD', 'RANGER', 'DOM-MUY 290', 94400.0, 'OPERATIVO'),
(171, 'VAP015', 'MIKASA', 'mtx 60hf', 'DOM-C9690', 201.0, 'OPERATIVO'),
(172, 'VAP006', 'WACKER', 'BS 502plus', 'S/N-172', 212.0, 'OPERATIVO'),
(173, 'VAP007', 'WACKER', 'BS 502plus', 'S/N-173', 223.0, 'OPERATIVO'),
(174, 'VAP010', 'CMC', 'V60', 'S/N-174', 234.0, 'OPERATIVO'),
(175, 'VAP011', 'CMC', 'V60', 'S/N-175', 245.0, 'OPERATIVO'),
(176, 'VAP012', 'CMC', 'V60', 'S/N-176', 256.0, 'OPERATIVO'),
(177, 'VAP013', 'WEBBER', 'SRV660', 'DOM-1105260', 267.0, 'OPERATIVO'),
(178, 'VAP014', 'WEBBER', 'SRV660', 'DOM-1108507', 278.0, 'OPERATIVO'),
(179, 'VAP016', 'MIKASA', 'mtx 60hf', 'DOM-C9696', 9.0, 'OPERATIVO'),
(180, 'VI001', 'INDHOR', '', 'S/N-180', 20.0, 'OPERATIVO'),
(181, 'VI002', 'INDHOR', '', 'S/N-181', 31.0, 'OPERATIVO'),
(182, 'VI003', 'INDHOR', '', 'S/N-182', 42.0, 'OPERATIVO'),
(183, 'VI004', 'INDHOR', '', 'S/N-183', 53.0, 'OPERATIVO')
ON DUPLICATE KEY UPDATE `marca`=VALUES(`marca`), `modelo`=VALUES(`modelo`), `numero_serie`=VALUES(`numero_serie`), `horas_motor`=VALUES(`horas_motor`), `estado`=VALUES(`estado`);

-- 2. Sistemas Logicos de la Maquina (`sistemas_maquinaria`)
INSERT INTO `sistemas_maquinaria` (`id`, `nombre`, `descripcion`) VALUES
(1, 'Motor', 'Block, inyeccion, admision, escape, turbo, refrigeracion y lubricacion de motor'),
(2, 'Hidraulica', 'Bombas principales, cilindros, banco de valvulas, mangueras de alta presion y enfriador'),
(3, 'Transmision', 'Convertidor de par, caja Powershift, diferencial y mandos finales'),
(4, 'Rodado', 'Tren de rodaje, orugas, cadenas, rolos, ruedas guia, neumaticos y mazas'),
(5, 'Electrico', 'Alternador, burro de arranque, baterias, sensores ECM y ramal electrico'),
(6, 'Chasis y Cabina', 'Bastidor articulado, articulacion central, cabina ROPS/FOPS, comandos y A/A'),
(7, 'Neumatica y Frenos', 'Compresor, valvulas de freno, pulmones y circuito de aire'),
(8, 'Implementos y Corte', 'Balde, vertedera, unas, cuchillas, escarificador y pernos de articulacion')
ON DUPLICATE KEY UPDATE `descripcion`=VALUES(`descripcion`);

-- 3. Catalogo Global de Repuestos (`repuestos_catalogo` - El Panol)
INSERT INTO `repuestos_catalogo` (`id`, `numero_parte_oem`, `descripcion`, `stock_actual`) VALUES
(1, '1R-1808', 'Filtro de Aceite de Motor Caterpillar Alta Eficiencia', 14),
(2, '1R-0749', 'Filtro de Combustible Primario Secundario CAT', 18),
(3, '326-1644', 'Filtro Separador de Agua y Combustible con Trampa', 9),
(4, '6I-2501', 'Filtro de Aire Primario Radial Seal', 11),
(5, '6I-2502', 'Filtro de Aire Secundario de Seguridad', 10),
(6, '1G-8878', 'Filtro Hidraulico y de Transmision Spin-On', 8),
(7, 'LF16015', 'Filtro de Aceite Motor Cummins / Fleetguard', 16),
(8, 'FS19765', 'Filtro Separador Combustible Fleetguard', 12),
(9, '5T-8259', 'Cuchilla de Vertedera 7 Pies Tratada al Boro (Motoniveladora)', 6),
(10, '1U-3352', 'Una / Diente de Balde Penetracion Serie J350', 24),
(11, '8E-6358', 'Perno y Seguro de Diente Serie J350', 30),
(12, '207-60-71182', 'Filtro Hidraulico Retorno Komatsu PC200', 7),
(13, '6732-81-3140', 'Correa Poliv Alternador y Ventilador 8PK', 5),
(14, 'CAT-HYDO-20L', 'Balde 20L Aceite Hidraulico ISO VG 46 / HYDO Advanced 10', 22),
(15, 'SHELL-R4-20L', 'Balde 20L Aceite Motor SAE 15W-40 Rimula R4 X', 28)
ON DUPLICATE KEY UPDATE `descripcion`=VALUES(`descripcion`), `stock_actual`=VALUES(`stock_actual`);

-- 4. Despiece Oficial Inicial (`despiece_equipos`)
INSERT INTO `despiece_equipos` (`equipo_id`, `repuesto_id`, `sistema_id`, `cantidad_por_equipo`) VALUES
(1, 1, 1, 1),
(1, 2, 1, 1),
(1, 3, 1, 1),
(1, 4, 1, 1),
(1, 5, 1, 1),
(1, 6, 2, 2),
(1, 9, 8, 2),
(2, 7, 1, 1),
(2, 8, 1, 1),
(2, 12, 2, 1),
(2, 10, 8, 5),
(2, 11, 8, 5)
ON DUPLICATE KEY UPDATE `cantidad_por_equipo`=VALUES(`cantidad_por_equipo`);

-- 5. Ordenes de Trabajo Iniciales (`ordenes_trabajo`)
INSERT INTO `ordenes_trabajo` (`id`, `equipo_id`, `fecha_ingreso`, `fecha_cierre`, `mecanico_asignado`, `tipo`, `horas_motor_actuales`, `estado`, `observaciones`) VALUES
(1, 1, '2026-10-15 08:00:00', '2026-10-15 14:30:00', 'Roberto Sanchez', 'PREVENTIVO', 56480.00, 'CERRADA', 'Service completo de 250 hs: cambio de filtros de motor, combustible e hidraulico.'),
(2, 2, '2026-10-18 09:15:00', '2026-10-18 17:00:00', 'Carlos Gomez', 'CORRECTIVO', 12450.00, 'CERRADA', 'Reemplazo de unas de balde desgastadas y revision de circuito hidraulico.'),
(3, 5, '2026-10-25 08:30:00', NULL, 'Roberto Sanchez', 'PREVENTIVO', 34200.00, 'EN_PROGRESO', 'Inspeccion general de tren de rodaje, frenos y lubricacion.')
ON DUPLICATE KEY UPDATE `estado`=VALUES(`estado`), `observaciones`=VALUES(`observaciones`);

-- 6. Repuestos Consumidos (`repuestos_utilizados` - alimenta el Despiece Empirico)
INSERT INTO `repuestos_utilizados` (`id`, `orden_trabajo_id`, `repuesto_id`, `cantidad_usada`, `fecha_uso`) VALUES
(1, 1, 1, 1, '2026-10-15 11:00:00'),
(2, 1, 2, 1, '2026-10-15 11:15:00'),
(3, 1, 6, 1, '2026-10-15 12:00:00'),
(4, 1, 15, 2, '2026-10-15 13:00:00'),
(5, 2, 10, 5, '2026-10-18 15:00:00'),
(6, 2, 11, 5, '2026-10-18 15:10:00'),
(7, 2, 12, 1, '2026-10-18 16:00:00')
ON DUPLICATE KEY UPDATE `cantidad_usada`=VALUES(`cantidad_usada`);

SET FOREIGN_KEY_CHECKS = 1;
